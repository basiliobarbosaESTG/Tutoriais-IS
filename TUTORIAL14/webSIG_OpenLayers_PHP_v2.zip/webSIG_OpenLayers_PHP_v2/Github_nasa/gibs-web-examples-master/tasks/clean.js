#!/usr/bin/env node

const shell = require('shelljs');

shell.rm('-rf', 'build', 'dist');
