<?php
   
   $tutors   = array();
   $elements   = null;
   
   function startElements($parser, $name, $attrs) {
      global $tutors, $elements;
      
      if(!empty($name)) {
         if ($name == 'BOOK') {
            $tutors []= array();
         }
         $elements = $name;
      }
   }
   
   function endElements($parser, $name) {
      global $elements;
      
      if(!empty($name)) {
         $elements = null;
      }
   }
   
   function characterData($parser, $data) {
      global $tutors, $elements;
      
      if(!empty($data)) {
         if ($elements == 'AUTHOR' || $elements == 'TITLE' ||  $elements == 'GENRE' ||  $elements == 'PRICE' || $elements == 'PUBLISH_DATE' || $elements == 'DESCRIPTION') {
            $tutors[count($tutors)-1][$elements] = trim($data);
         }
      }
   }

   function getDataFile() {
      global $tutors, $elements;
   
   $parser = xml_parser_create(); 
   
   xml_set_element_handler($parser, "startElements", "endElements");
   xml_set_character_data_handler($parser, "characterData");
   
   if (!($handle = fopen('files/books.xml', "r"))) {
      die("could not open XML input");
   }
   
   while($data = fread($handle, 8096)) {
      xml_parse($parser, $data); 
   }
   
   xml_parser_free($parser); 

   $dataValue = "";
   foreach($tutors as $course) {
      $dataValue .= "author - ".$course['AUTHOR'].'<br/>';
      $dataValue .= "title - ".$course['TITLE'].'<br/>';
      $dataValue .= "genre - ".$course['GENRE'].'<br/>';
      $dataValue .= "price - ".$course['PRICE'].'<br/>'; 
      $dataValue .= "publish_date - ".$course['PUBLISH_DATE'].'<br/>';
      $dataValue .= "description - ".$course['DESCRIPTION'].'<hr/>'; 
   }

   return $dataValue;
   
   }
?>