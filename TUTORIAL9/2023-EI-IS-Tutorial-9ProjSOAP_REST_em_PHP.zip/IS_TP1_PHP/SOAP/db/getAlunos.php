<?php

    function getAlunos(){

        try {

            include_once("config/conn.php");
    
            $PDO->beginTransaction();
    
            $query = "SELECT * FROM alunos";
    
            $result = $PDO->query($query)->fetchAll();
    
            return $result;
        }catch(PDOException $e){
            $PDO->rollBack();
            var_dump($e);
        }
    }
?>