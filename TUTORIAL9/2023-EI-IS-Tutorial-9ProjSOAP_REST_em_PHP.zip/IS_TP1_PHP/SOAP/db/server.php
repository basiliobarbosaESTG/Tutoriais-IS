<?php
    require_once("lib/nusoap.php");
    include_once("getAlunos.php");
   
    $server = new nusoap_server();

    $server->configureWSDL('urn:Server');
    $server->wsdl->schemaTargetNamespace = 'urn:Server';
    

    function getData($file){
        return getDataFromFile();
    }   

    function getDataFromFile(){
        $data = getAlunos();

                $dom = new DOMDocument();
                $dom->encoding = 'utf-8';
                $dom->xmlVersion = '1.0';
                $dom->formatOutput = true;
                $xml_file_name = 'alunos.xml';
                $root = $dom->createElement('alunos');
        
                foreach ($data as $row) {
                    $aluno_node = $dom->createElement('aluno');
                    $child_node_id = $dom->createElement('id', $row["id"]);
                    $aluno_node->appendChild($child_node_id);
                    $child_node_nome = $dom->createElement('nome', $row["nome"]);
                    $aluno_node->appendChild($child_node_nome);
                    $root->appendChild($aluno_node);
                }
        
                $dom->appendChild($root);
                
                $dom->save($xml_file_name);
                
                $dataDom = file_get_contents($xml_file_name) or die("Failed to load");
                
                return $dataDom;
    }

    $server->register (
        'getData',
        array("file"=>"xsd:string"),
        array("return"=>"xsd:string"),
        'urn:Server.getData',
        'urn:Server.getData',
        'rpc',
        'encoded',
        'obter dados de uma base de dados'
    );

    $HTTP_RAW_POST_DATA = isset( $HTTP_RAW_POST_DATA ) ? $HTTP_RAW_POST_DATA : file_get_contents("php://input");
        $server->service($HTTP_RAW_POST_DATA);
?>