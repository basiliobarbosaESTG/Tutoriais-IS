<?php
    require_once "lib/nusoap.php";
    
    $client = new nusoap_client('http://localhost/IS_TP1_PHP/SOAP/db/server.php?wsdl');

    $param = array("");

    header('Content-Type: application/xml');
    $result = $client->call('getData', $param);
    print_r($result);
?>