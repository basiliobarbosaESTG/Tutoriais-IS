<?php

   function getDataFile() {
   $dom = new domDocument; 
   
   $dom->load("files/books.xml"); 
   
   $dom->preserveWhiteSpace = false; 
   
   $tables = $dom->getElementsByTagName('catalog'); 
   
   $rows = $tables->item(0)->getElementsByTagName('book'); 
    
   $data = "";
  
   foreach ($rows as $row) {
      $author = $row->getElementsByTagName('author');
      $title = $row->getElementsByTagName('title');
      $genre = $row->getElementsByTagName('genre');
      $price = $row->getElementsByTagName('price');
      $publish_date = $row->getElementsByTagName('publish_date');
      $description = $row->getElementsByTagName('description');
      $data .= 'author: '.$author->item(0)->nodeValue.'<br />'; 
      $data .= 'title: '.$title->item(0)->nodeValue.'<br />'; 
      $data .= 'genre: '.$genre->item(0)->nodeValue; 
      $data .= 'price: '.$price->item(0)->nodeValue.'<br />'; 
      $data .= 'publish_date: '.$publish_date->item(0)->nodeValue.'<br />'; 
      $data .= 'description: '.$description->item(0)->nodeValue; 
      $data .= '<hr />'; 
   } 

   return $data;
      
   }

?>