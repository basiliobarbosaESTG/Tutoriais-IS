<?php
    require_once("lib/nusoap.php");
    require_once("readFile.php");
   
    $server = new nusoap_server();

    $server->configureWSDL('urn:Server');
    $server->wsdl->schemaTargetNamespace = 'urn:Server';


    function getData($file){
        return getDataFromFile();
    }   

    function getDataFromFile(){
       
        $data = getDataFile();
        return $data;
    }

    $server->register (
        'getData',
        array("file"=>"xsd:string"),
        array("return"=>"xsd:string"),
        'urn:Server.getData',
        'urn:Server.getData',
        'rpc',
        'encoded',
        'obter dados de um ficheiro xml'
    );

    $HTTP_RAW_POST_DATA = isset( $HTTP_RAW_POST_DATA ) ? $HTTP_RAW_POST_DATA : file_get_contents("php://input");
        $server->service($HTTP_RAW_POST_DATA);
?>