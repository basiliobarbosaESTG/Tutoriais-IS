<?php
require_once("AlunosRestHandler.php");
		
$view = "";
if(isset($_GET["view"]))
	$view = $_GET["view"];
	
switch($view){

	case "all":
		// to handle REST Url /mobile/list/
		$AlunosRestHandler = new AlunosRestHandler();
		$AlunosRestHandler->getAllAlunos();
		break;
}

?>
