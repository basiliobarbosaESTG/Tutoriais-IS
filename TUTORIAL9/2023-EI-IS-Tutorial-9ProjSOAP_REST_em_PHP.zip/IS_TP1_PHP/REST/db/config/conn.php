<?php
    $servername = "localhost:3306";
    $username = "userdb";
    $password = "teste";
    $database = "is";

    try {
        $PDO = new PDO("mysql:host=$servername;dbname=$database", $username, $password);

        $PDO->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $PDO->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

    } catch (PDOException $e) {
        var_dump($e);
    }
?>