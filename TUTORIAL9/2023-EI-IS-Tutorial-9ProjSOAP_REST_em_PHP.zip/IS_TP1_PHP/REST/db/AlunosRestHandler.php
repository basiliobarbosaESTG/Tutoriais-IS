<?php
require_once("SimpleRest.php");
require_once("getAlunos.php");
		
class AlunosRestHandler extends SimpleRest {

	function getAllAlunos() {	

        $rawData = getAlunos();
		if(empty($rawData)) {
			$statusCode = 404;
			//$rawData = array('error' => 'No alunos found!');		
		} else {
			$statusCode = 200;
		}

		$requestContentType = $_SERVER['HTTP_ACCEPT'];
		$this ->setHttpHeaders($requestContentType, $statusCode);
	
		if(strpos($requestContentType,'text/html') !== false){
                //print_r($rawData);
			header('Content-Type: application/xml');
			$response = $this->encodeXml($rawData);
			return $response;
        }
	}
	
	public function encodeXml($responseData) {
        $dom = new DOMDocument();
        $dom->encoding = 'utf-8';
        $dom->xmlVersion = '1.0';
        $dom->formatOutput = true;
        $xml_file_name = 'alunos.xml';
        $root = $dom->createElement('alunos');

        foreach ($responseData as $row) {
                $aluno_node = $dom->createElement('aluno');
                $child_node_id = $dom->createElement('id', $row["id"]);
                $aluno_node->appendChild($child_node_id);
                $child_node_nome = $dom->createElement('nome', $row["nome"]);
                $aluno_node->appendChild($child_node_nome);
                $root->appendChild($aluno_node);
        }

        $dom->appendChild($root);
        $dom->save($xml_file_name);

        $data = file_get_contents($xml_file_name) or die("Failed to load");
        print_r($data);
        }
        
}
?>