<?php

$dom = new domDocument; 
   
   $dom->load("files/books.xml"); 
   
   $dom->preserveWhiteSpace = false; 
   
   $tables = $dom->getElementsByTagName('catalog'); 
   
   $rows = $tables->item(0)->getElementsByTagName('book'); 
   
   foreach ($rows as $row) {
      
      $author = $row->getElementsByTagName('author');
      $title = $row->getElementsByTagName('title');
      $genre = $row->getElementsByTagName('genre');
      $price = $row->getElementsByTagName('price');
      $publish_date = $row->getElementsByTagName('publish_date');
      $description = $row->getElementsByTagName('description');
      
      
      echo 'author: '.$author->item(0)->nodeValue.'<br />'; 
      echo 'title: '.$title->item(0)->nodeValue.'<br />'; 
      echo 'genre: '.$genre->item(0)->nodeValue; 
      echo 'price: '.$price->item(0)->nodeValue.'<br />'; 
      echo 'publish_date: '.$publish_date->item(0)->nodeValue.'<br />'; 
      echo 'description: '.$description->item(0)->nodeValue; 
      echo '<hr />'; 
   }

?>