<?php
require_once("SimpleRest.php");
require_once("readFile.php");
		
class BooksRestHandler extends SimpleRest {

	function getAllBooks() {	

                $rawData = getDataFile();
                        if(empty($rawData)) {
                                $statusCode = 404;
                                //$rawData = array('error' => 'No books found!');		
                        } else {
                                $statusCode = 200;
                        }

                        $requestContentType = $_SERVER['HTTP_ACCEPT'];
                        $this ->setHttpHeaders($requestContentType, $statusCode);
                
                        if(strpos($requestContentType,'text/html') !== false){
                //print_r($rawData);
                                header('Content-Type: text/html');
                                $response = $this->encodeXml($rawData);
                                return $response;
                }
	}
	
	public function encodeXml($responseData) {
                
                print_r($responseData);
	}
}
?>