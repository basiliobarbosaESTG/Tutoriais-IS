package com.is2;

// Imports
import java.util.ArrayList;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "catalog") // Tag raíz da lista da livros
@XmlAccessorType(XmlAccessType.FIELD)
public class Books {
    
    @XmlElement(name = "book")
    private ArrayList<Book> books = null; // Lista de elementos de tipo Book

    // Getters & Setters
    public ArrayList<Book> getBooks() {
        return books;
    }

    public void setBooks(ArrayList<Book> books) {
        this.books = books;
    }

}
