package com.is2;

// Imports
import java.io.File;
import java.lang.reflect.InvocationTargetException;
import javax.ws.rs.*;
import javax.ws.rs.core.*;
import java.util.*;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

@Path("/simples")
public class Simples_ws_rest {
   
    @GET
    @Produces(MediaType.APPLICATION_XML) // Anotação que permite que a ArrayList seja devolvida em formato XML
    public ArrayList<Simple> getSimples() throws JAXBException, InvocationTargetException {
        
        // Try-Catch do parsing via JAXB do ficheiro
        try {
            JAXBContext jaxbContext; // Parser usado (JAXB)
            File xmlFile = new File("C:\\IS_1920\\TP1\\simple.xml"); // Cria variável de ficheiro local indicando o path do ficheiro ""simple.xml"
            jaxbContext = JAXBContext.newInstance(Simples.class); // Cria instance do parse do JAXB na classe da lista de livros
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller(); // Cria interface responsável para "des-serializar" o ficheiro XML para objeto Java
            Simples simples = (Simples) jaxbUnmarshaller.unmarshal(xmlFile); // Des-serializa o ficheiro XML para objeto Java
           
            return simples.getSimples();
           
        }catch (JAXBException e) {
        }
        
        return null;
        
        
    }
    
}
