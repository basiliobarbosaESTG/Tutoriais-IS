package com.is2;

// Imports
import java.util.ArrayList;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "breakfast_menu") // Tag raíz da lista de foods
@XmlAccessorType(XmlAccessType.FIELD)
public class Simples {
    
  @XmlElement(name = "food")
    private ArrayList<Simple> simples = null; // Lista de elementos de tipo food

    // Getters & Setters
    public ArrayList<Simple> getSimples() {
        return simples;
    }

    public void setSimples(ArrayList<Simple> simples) {
        this.simples = simples;
    }
    
}
