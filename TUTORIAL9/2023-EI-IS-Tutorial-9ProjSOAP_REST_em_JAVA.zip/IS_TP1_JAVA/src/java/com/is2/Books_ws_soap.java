package com.is2;

// Imports
import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

// Definição do web-service SOAP
@WebService(serviceName = "Books_ws_soap")
public class Books_ws_soap {

    // Definição do método
    @WebMethod(operationName = "getBooks")
    public ArrayList<Book> getBooks() throws JAXBException, InvocationTargetException {
        
        // Try-Catch do parsing via JAXB do ficheiro
        try {
            JAXBContext jaxbContext;  // Parser usado (JAXB)
            File xmlFile = new File("C:\\IS_1920\\TP1\\books.xml"); // Cria variável de ficheiro local indicando o path do ficheiro "books.xml"
            jaxbContext = JAXBContext.newInstance(Books.class); // Cria instance do parse do JAXB na classe da lista de livros
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller(); // Cria interface responsável para "des-serializar" o ficheiro XML para objeto Java
            Books books = (Books) jaxbUnmarshaller.unmarshal(xmlFile); // Des-serializa o ficheiro XML para objeto Java
           
            return books.getBooks();
           
        } catch (JAXBException e){
        }
        
        return null;

    }
}
