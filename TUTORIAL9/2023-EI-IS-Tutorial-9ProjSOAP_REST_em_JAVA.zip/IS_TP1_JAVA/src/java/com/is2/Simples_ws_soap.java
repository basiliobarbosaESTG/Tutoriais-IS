package com.is2;

// Imports
import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

// Definição do web-service SOAP
@WebService(serviceName = "Simples_ws_soap")
public class Simples_ws_soap {

    // Definição do método
    @WebMethod(operationName = "getSimples")
    public ArrayList<Simple> getSimples() throws JAXBException, InvocationTargetException {
        
        // Try-Catch do parsing via JAXB do ficheiro
        try {
            JAXBContext jaxbContext;  // Parser usado (JAXB)
            File xmlFile = new File("C:\\IS_1920\\TP1\\simple.xml"); // Cria variável de ficheiro local indicando o path do ficheiro ""simple.xml"
            jaxbContext = JAXBContext.newInstance(Simples.class); // Cria instance do parse do JAXB na classe da lista de foods
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller(); // Cria interface responsável para "des-serializar" o ficheiro XML para objeto Java
            Simples simples = (Simples) jaxbUnmarshaller.unmarshal(xmlFile); // Des-serializa o ficheiro XML para objeto Java
           
            return simples.getSimples();
           
        } catch (JAXBException e){
        }
        
        return null;
        
    }
}
