package com.is.db;

// Imports
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.ws.rs.*;
import javax.ws.rs.core.*;
import java.util.*;

@Path("/alunos")
public class Alunos_ws_rest {
    
    @GET 
    @Produces(MediaType.APPLICATION_XML) // Anotação que permite que a ArrayList seja devolvida em formato XML
    public ArrayList<Alunos> getAlunos() {
        ArrayList<Alunos> alunos = new ArrayList<>();
        
        // Try-Catch de ligação à BD e query da tabela alunos
        try{
           Class.forName("com.mysql.jdbc.Driver");
           String url = "jdbc:mysql://localhost:3306/is?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
           Connection conn = DriverManager.getConnection(url, "userdb", "teste"); // Conexão com credenciais de ligação do MySQL
           Statement st = conn.createStatement();
           ResultSet srs = st.executeQuery("SELECT * FROM alunos");
           
           // Adição do resultado da query à resposta XML
           while (srs.next()) {
                Alunos al = new Alunos();
                al.setId(srs.getInt("id"));
                al.setNome(srs.getString("nome"));
                alunos.add(al);
            }
           
           return alunos;
           
        }catch(ClassNotFoundException | SQLException e){
        }
        
        return null;
    }
    
}
